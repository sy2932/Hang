package RW_Tool.Ops_User.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.List;

@Entity
@Table(name = "notifications")
public class Notification {
    @Id
    private String id;

    @ElementCollection
    @CollectionTable(name = "notification_files", joinColumns = @JoinColumn(name = "notification_id"))
    private List<String> fileIds;

    private String folderId;
    private String folderPath;
    private LocalDateTime receivedAt;
    private boolean read = false;
    private String groupName;
    private LocalDateTime sentAt;

    public Notification() {
        // Default constructor required by JPA
    }

    public Notification(String id, List<String> fileIds, String folderId, String folderPath,
                       LocalDateTime receivedAt, String groupName) {
        this.id = id;
        this.fileIds = fileIds;
        this.folderId = folderId;
        this.folderPath = folderPath;
        this.receivedAt = receivedAt;
        this.groupName = groupName;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public List<String> getFileIds() {
        return fileIds;
    }

    public void setFileIds(List<String> fileIds) {
        this.fileIds = fileIds;
    }

    public String getFolderId() {
        return folderId;
    }

    public void setFolderId(String folderId) {
        this.folderId = folderId;
    }

    public String getFolderPath() {
        return folderPath;
    }

    public void setFolderPath(String folderPath) {
        this.folderPath = folderPath;
    }

    public LocalDateTime getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(LocalDateTime receivedAt) {
        this.receivedAt = receivedAt;
    }

    public boolean isRead() {
        return read;
    }

    public void setRead(boolean read) {
        this.read = read;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public LocalDateTime getSentAt() {
        return sentAt;
    }

    public void setSentAt(LocalDateTime sentAt) {
        this.sentAt = sentAt;
    }
}
