package com.example.LOGIN_SIGNUP.model;

public class Role {
    public enum Role {
        ADMIN,
        OPS,
        EMPLOYEE;
    }

}
