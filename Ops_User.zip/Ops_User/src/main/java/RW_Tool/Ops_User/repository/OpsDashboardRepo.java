package RW_Tool.Ops_User.repository;

import RW_Tool.Ops_User.model.OpsDashboard;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OpsDashboardRepo extends JpaRepository<OpsDashboard,Long> {
}
