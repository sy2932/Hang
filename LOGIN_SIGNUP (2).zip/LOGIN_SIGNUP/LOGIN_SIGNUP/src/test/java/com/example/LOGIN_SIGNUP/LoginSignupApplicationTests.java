package com.example.LOGIN_SIGNUP;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LoginSignupApplicationTests {

	@Test
	void contextLoads() {
	}

}
