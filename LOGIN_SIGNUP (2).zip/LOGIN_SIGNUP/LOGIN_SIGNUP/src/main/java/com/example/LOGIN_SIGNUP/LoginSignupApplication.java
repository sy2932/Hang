package com.example.LOGIN_SIGNUP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class LoginSignupApplication {

    public static void main(String[] args) {
        SpringApplication.run(LoginSignupApplication.class, args);

        // Correct placement of the print statement
        System.out.println("Hello World");
    }
}

