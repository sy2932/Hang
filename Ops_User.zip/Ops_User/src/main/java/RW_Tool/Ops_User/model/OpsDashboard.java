package RW_Tool.Ops_User.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class OpsDashboard {
    @Id
    private long OpsUserId;
    private long EmployeeId;
    private String EmployeeName;
    private String Department;
    private String Group;

    public OpsDashboard() {
        // Default constructor required by JPA
    }

    public OpsDashboard(long opsUserId, long employeeId, String employeeName, String department, String group) {
        OpsUserId = opsUserId;
        EmployeeId = employeeId;
        EmployeeName = employeeName;
        Department = department;
        Group = group;
    }

    public long getOpsUserId() {
        return OpsUserId;
    }

    public void setOpsUserId(long opsUserId) {
        OpsUserId = opsUserId;
    }

    public long getEmployeeId() {
        return EmployeeId;
    }

    public void setEmployeeId(long employeeId) {
        EmployeeId = employeeId;
    }

    public String getEmployeeName() {
        return EmployeeName;
    }

    public void setEmployeeName(String employeeName) {
        EmployeeName = employeeName;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getGroup() {
        return Group;
    }

    public void setGroup(String group) {
        Group = group;
    }
}
