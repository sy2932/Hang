package com.example.LOGIN_SIGNUP.service;

import com.example.LOGIN_SIGNUP.dto.ForgotPasswordRequest;
import com.example.LOGIN_SIGNUP.dto.LoginRequest;
import com.example.LOGIN_SIGNUP.dto.SignUpRequest;
import com.example.LOGIN_SIGNUP.model.Role;
import com.example.LOGIN_SIGNUP.model.User;
import com.example.LOGIN_SIGNUP.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.Optional;

public class UserService {
    @Service
    public class UserService {

        @Autowired
        private UserRepository userRepository;

        @Autowired
        private PasswordEncoder passwordEncoder;

        public void registerUser(SignUpRequest request) {
            if (userRepository.findByEmail(request.getEmail()).isPresent()) {
                throw new RuntimeException("Email is already in use");
            }
            User user = new User();
            user.setEmail(request.getEmail());
            user.setPassword(passwordEncoder.encode(request.getPassword()));
            user.setsecurityQuestion(request.getsecurityQuestion());
            user.setsecurityAnswer(request.getsecurityAnswer());
            user.setRole(Role.valueOf(request.getRole().toUpperCase()));
            userRepository.save(user);
        }

        public ResponseEntity<?> loginUser(LoginRequest request) {
            Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
            if (userOpt.isEmpty()) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
            }
            User user = userOpt.get();
            if (!passwordEncoder.matches(request.getPassword(), user.getPassword())) {
                return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("Invalid email or password");
            }
            // Successful login - can return token or user details (token implementation optional)
            return ResponseEntity.ok("Login successful for user: " + user.getEmail());
        }

        public boolean resetPassword(ForgotPasswordRequest request) {
            Optional<User> userOpt = userRepository.findByEmail(request.getEmail());
            if (userOpt.isEmpty()) return false;

            User user = userOpt.get();
            if (user.getsecurityQuestion().equals(request.getsecurityQuestion()) &&
                    user.getsecurityAnswer().equalsIgnoreCase(request.getsecurityAnswer())) {
                user.setPassword(passwordEncoder.encode(request.getNewPassword()));
                userRepository.save(user);
                return true;
            }
            return false;
        }
    }

}
