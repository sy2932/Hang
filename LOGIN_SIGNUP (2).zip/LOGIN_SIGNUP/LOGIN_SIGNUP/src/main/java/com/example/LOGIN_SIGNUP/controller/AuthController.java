package com.example.LOGIN_SIGNUP.controller;

import com.example.LOGIN_SIGNUP.dto.LoginRequest;
import com.example.LOGIN_SIGNUP.dto.SignUpRequest;
import com.example.LOGIN_SIGNUP.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

public class AuthController {
    @RestController
    @RequestMapping("/api/auth")
    public class AuthController {

        @Autowired
        private UserService userService;

        @PostMapping("/signup")
        public ResponseEntity<?> signup(@RequestBody SignUpRequest request) {
            // Validate password match, call service to save user
            if (!request.getPassword().equals(request.getRePassword())) {
                return ResponseEntity.badRequest().body("Passwords do not match");
            }
            userService.registerUser(request);
            return ResponseEntity.ok("User registered successfully");
        }

        @PostMapping("/login")
        public ResponseEntity<?> login(@RequestBody LoginRequest request) {
            // Authenticate user and return token or session info
            return userService.loginUser(request);
        }

        @PostMapping("/forgot-password")
        public ResponseEntity<?> forgotPassword(@RequestBody ForgotPasswordRequest request) {
            // Validate email, security question & answer, reset password flow
            boolean reset = userService.resetPassword(request);
            if (reset) {
                return ResponseEntity.ok("Password reset successfully");
            } else {
                return ResponseEntity.badRequest().body("Invalid credentials or security answer");
            }
        }
    }

}
