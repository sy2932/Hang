package RW_Tool.Ops_User.model;

import jakarta.persistence.*;

@Entity
@Table(name = "file_info")
public class FileInfo {
    @Id
    private String id;
    private String name;
    private Long size;
    private String type;
    private String path;

    public FileInfo() {
        // Default constructor required by JPA
    }

    public FileInfo(String id, String name, Long size, String type, String path) {
        this.id = id;
        this.name = name;
        this.size = size;
        this.type = type;
        this.path = path;
    }

    // Getters and Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Long getSize() {
        return size;
    }

    public void setSize(Long size) {
        this.size = size;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }
}
