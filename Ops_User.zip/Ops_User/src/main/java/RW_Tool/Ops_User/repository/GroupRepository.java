package RW_Tool.Ops_User.repository;

import RW_Tool.Ops_User.model.Group;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import java.util.List;
import java.util.Optional;

public interface GroupRepository extends JpaRepository<Group, Long> {

    Optional<Group> findByName(String name);

    @Query("SELECT g FROM Group g WHERE LOWER(g.name) NOT IN ('general', 'unassigned')")
    List<Group> findAllActiveGroups();

    @Query("SELECT g FROM Group g WHERE LOWER(g.name) NOT IN ('hr', 'it', 'finance', 'marketing', 'general', 'unassigned')")
    List<Group> findCustomGroups();
}
