package RW_Tool.Ops_User.service;

import RW_Tool.Ops_User.model.*;
import RW_Tool.Ops_User.repository.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class OpsDashboardService {
    private final OpsDashboardRepo opsDashboardRepo;
    private final EmployeeRepository employeeRepository;
    private final GroupRepository groupRepository;
    private final NotificationRepository notificationRepository;

    public OpsDashboardService(OpsDashboardRepo opsDashboardRepo,
                              EmployeeRepository employeeRepository,
                              GroupRepository groupRepository,
                              NotificationRepository notificationRepository) {
        this.opsDashboardRepo = opsDashboardRepo;
        this.employeeRepository = employeeRepository;
        this.groupRepository = groupRepository;
        this.notificationRepository = notificationRepository;
    }

    // Employee Operations
    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public List<Employee> getApprovedEmployees() {
        return employeeRepository.findAllApprovedEmployees();
    }

    public List<Employee> searchEmployees(String query, String group) {
        if (group == null || group.isEmpty()) {
            if (query == null || query.isEmpty()) {
                return getApprovedEmployees();
            }
            return employeeRepository.findByNameContainingIgnoreCase(query);
        } else {
            if (query == null || query.isEmpty()) {
                return employeeRepository.findByAdminAssignedGroup(group);
            }
            return employeeRepository.findByGroupAndNameContaining(group, query);
        }
    }

    public Optional<Employee> getEmployeeByEmail(String email) {
        return employeeRepository.findByEmail(email);
    }

    public Employee saveEmployee(Employee employee) {
        return employeeRepository.save(employee);
    }

    public void deleteEmployee(Long id) {
        employeeRepository.deleteById(id);
    }

    // Group Operations
    public List<Group> getAllGroups() {
        return groupRepository.findAll();
    }

    public List<Group> getActiveGroups() {
        return groupRepository.findAllActiveGroups();
    }

    public List<Group> getCustomGroups() {
        return groupRepository.findCustomGroups();
    }

    public Optional<Group> getGroupByName(String name) {
        return groupRepository.findByName(name);
    }

    public Group saveGroup(Group group) {
        return groupRepository.save(group);
    }

    public void deleteGroup(Long id) {
        groupRepository.deleteById(id);
    }

    public void updateGroupUserCounts() {
        List<Group> groups = getAllGroups();
        for (Group group : groups) {
            long userCount = employeeRepository.findByAdminAssignedGroup(group.getName()).size();
            group.setUsers((int) userCount);
            groupRepository.save(group);
        }
    }

    // Notification Operations
    public List<Notification> getAllNotifications() {
        return notificationRepository.findAllOrderByReceivedAtDesc();
    }

    public List<Notification> getUnreadNotifications() {
        return notificationRepository.findUnreadNotifications();
    }

    public Long getUnreadNotificationCount() {
        return notificationRepository.countUnreadNotifications();
    }

    public Notification saveNotification(Notification notification) {
        if (notification.getReceivedAt() == null) {
            notification.setReceivedAt(LocalDateTime.now());
        }
        return notificationRepository.save(notification);
    }

    public void deleteNotification(String id) {
        notificationRepository.deleteById(id);
    }

    public void markNotificationAsRead(String id) {
        Optional<Notification> notification = notificationRepository.findById(id);
        if (notification.isPresent()) {
            notification.get().setRead(true);
            notificationRepository.save(notification.get());
        }
    }

    public void forwardFilesToGroup(String notificationId, String groupName) {
        Optional<Notification> notification = notificationRepository.findById(notificationId);
        if (notification.isPresent()) {
            Notification notif = notification.get();

            // Create new notification for the target group
            Notification groupNotification = new Notification();
            groupNotification.setId("group-" + System.currentTimeMillis() + "-" +
                                  Math.round(Math.random() * 1000000));
            groupNotification.setFileIds(notif.getFileIds());
            groupNotification.setFolderPath(notif.getFolderPath());
            groupNotification.setGroupName(groupName);
            groupNotification.setSentAt(LocalDateTime.now());
            groupNotification.setReceivedAt(LocalDateTime.now());

            notificationRepository.save(groupNotification);

            // Remove the original ops notification
            notificationRepository.deleteById(notificationId);
        }
    }

    // Dashboard Operations
    public List<OpsDashboard> getAllOpsDashboardEntries() {
        return opsDashboardRepo.findAll();
    }

    public OpsDashboard saveOpsDashboardEntry(OpsDashboard entry) {
        return opsDashboardRepo.save(entry);
    }

    public void deleteOpsDashboardEntry(Long id) {
        opsDashboardRepo.deleteById(id);
    }

    // Initialize default groups if none exist
    public void initializeDefaultGroups() {
        if (groupRepository.count() == 0) {
            List<Group> defaultGroups = List.of(
                new Group("HR", 0),
                new Group("IT", 0),
                new Group("Finance", 0),
                new Group("Marketing", 0)
            );
            groupRepository.saveAll(defaultGroups);
        }
    }
}
