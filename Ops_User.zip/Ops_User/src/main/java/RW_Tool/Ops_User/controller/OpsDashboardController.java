package RW_Tool.Ops_User.controller;

import RW_Tool.Ops_User.model.*;
import RW_Tool.Ops_User.service.OpsDashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/ops")
public class OpsDashboardController {

    private final OpsDashboardService opsDashboardService;

    public OpsDashboardController(OpsDashboardService opsDashboardService) {
        this.opsDashboardService = opsDashboardService;
    }

    // Employee endpoints
    @GetMapping("/employees")
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(opsDashboardService.getApprovedEmployees());
    }

    @GetMapping("/employees/search")
    public ResponseEntity<List<Employee>> searchEmployees(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String group) {
        return ResponseEntity.ok(opsDashboardService.searchEmployees(query, group));
    }

    @GetMapping("/employees/{email}")
    public ResponseEntity<Employee> getEmployeeByEmail(@PathVariable String email) {
        Optional<Employee> employee = opsDashboardService.getEmployeeByEmail(email);
        return employee.map(ResponseEntity::ok)
                      .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/employees")
    public ResponseEntity<Employee> createEmployee(@RequestBody Employee employee) {
        Employee savedEmployee = opsDashboardService.saveEmployee(employee);
        return ResponseEntity.ok(savedEmployee);
    }

    @PutMapping("/employees/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @RequestBody Employee employee) {
        employee.setId(id);
        Employee updatedEmployee = opsDashboardService.saveEmployee(employee);
        return ResponseEntity.ok(updatedEmployee);
    }

    @DeleteMapping("/employees/{id}")
    public ResponseEntity<Void> deleteEmployee(@PathVariable Long id) {
        opsDashboardService.deleteEmployee(id);
        return ResponseEntity.ok().build();
    }

    // Group endpoints
    @GetMapping("/groups")
    public ResponseEntity<List<Group>> getAllGroups() {
        return ResponseEntity.ok(opsDashboardService.getActiveGroups());
    }

    @GetMapping("/groups/custom")
    public ResponseEntity<List<Group>> getCustomGroups() {
        return ResponseEntity.ok(opsDashboardService.getCustomGroups());
    }

    @PostMapping("/groups")
    public ResponseEntity<Group> createGroup(@RequestBody Group group) {
        Group savedGroup = opsDashboardService.saveGroup(group);
        return ResponseEntity.ok(savedGroup);
    }

    @PutMapping("/groups/{id}")
    public ResponseEntity<Group> updateGroup(@PathVariable Long id, @RequestBody Group group) {
        group.setId(id);
        Group updatedGroup = opsDashboardService.saveGroup(group);
        return ResponseEntity.ok(updatedGroup);
    }

    @DeleteMapping("/groups/{id}")
    public ResponseEntity<Void> deleteGroup(@PathVariable Long id) {
        opsDashboardService.deleteGroup(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/groups/update-counts")
    public ResponseEntity<Void> updateGroupUserCounts() {
        opsDashboardService.updateGroupUserCounts();
        return ResponseEntity.ok().build();
    }

    // Notification endpoints
    @GetMapping("/notifications")
    public ResponseEntity<List<Notification>> getAllNotifications() {
        return ResponseEntity.ok(opsDashboardService.getAllNotifications());
    }

    @GetMapping("/notifications/unread")
    public ResponseEntity<List<Notification>> getUnreadNotifications() {
        return ResponseEntity.ok(opsDashboardService.getUnreadNotifications());
    }

    @GetMapping("/notifications/unread/count")
    public ResponseEntity<Long> getUnreadNotificationCount() {
        return ResponseEntity.ok(opsDashboardService.getUnreadNotificationCount());
    }

    @PostMapping("/notifications")
    public ResponseEntity<Notification> createNotification(@RequestBody Notification notification) {
        Notification savedNotification = opsDashboardService.saveNotification(notification);
        return ResponseEntity.ok(savedNotification);
    }

    @PutMapping("/notifications/{id}/read")
    public ResponseEntity<Void> markNotificationAsRead(@PathVariable String id) {
        opsDashboardService.markNotificationAsRead(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/notifications/{id}/forward")
    public ResponseEntity<Void> forwardNotificationToGroup(
            @PathVariable String id,
            @RequestParam String groupName) {
        opsDashboardService.forwardFilesToGroup(id, groupName);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/notifications/{id}")
    public ResponseEntity<Void> deleteNotification(@PathVariable String id) {
        opsDashboardService.deleteNotification(id);
        return ResponseEntity.ok().build();
    }

    // Dashboard specific endpoints
    @GetMapping("/dashboard")
    public ResponseEntity<List<OpsDashboard>> getAllOpsDashboardEntries() {
        return ResponseEntity.ok(opsDashboardService.getAllOpsDashboardEntries());
    }

    @PostMapping("/dashboard")
    public ResponseEntity<OpsDashboard> createOpsDashboardEntry(@RequestBody OpsDashboard entry) {
        OpsDashboard savedEntry = opsDashboardService.saveOpsDashboardEntry(entry);
        return ResponseEntity.ok(savedEntry);
    }

    @DeleteMapping("/dashboard/{id}")
    public ResponseEntity<Void> deleteOpsDashboardEntry(@PathVariable Long id) {
        opsDashboardService.deleteOpsDashboardEntry(id);
        return ResponseEntity.ok().build();
    }

    // Initialize default groups
    @PostMapping("/initialize")
    public ResponseEntity<Void> initializeDefaultGroups() {
        opsDashboardService.initializeDefaultGroups();
        return ResponseEntity.ok().build();
    }
}
