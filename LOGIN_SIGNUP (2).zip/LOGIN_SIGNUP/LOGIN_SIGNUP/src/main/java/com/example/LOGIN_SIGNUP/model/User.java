package com.example.LOGIN_SIGNUP.model;

import jakarta.persistence.*;

import javax.management.relation.Role;

public class User {
    @Entity
    @Table(name = "users")
    public class User {
        @Id
        @GeneratedValue(strategy = GenerationType.IDENTITY)
        private Long id;

        public void setEmail(String email) {
            this.email = email;
        }

        @Column(nullable = false, unique = true)
        private String email;

        @Column(nullable = false)
        private String password;

        @Enumerated(EnumType.STRING)
        private Role role;

        public String getEmail() {
            return email;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public Role getRole() {
            return role;
        }

        public void setRole(Role role) {
            this.role = role;
        }

        public String getSecurityQuestion() {
            return securityQuestion;
        }

        public void setSecurityQuestion(String securityQuestion) {
            this.securityQuestion = securityQuestion;
        }

        public String getSecurityAnswer() {
            return securityAnswer;
        }

        public void setSecurityAnswer(String securityAnswer) {
            this.securityAnswer = securityAnswer;
        }

        @Column(nullable = false)
        private String securityQuestion;

        public void setId(Long id) {
            this.id = id;
        }

        @Column(nullable = false)
        private String securityAnswer;

        public Long getId() {
            return id;
        }
    }

}
