package com.example.LOGIN_SIGNUP.dto;

public class ForgotPasswordRequest {
    public class ForgotPasswordRequest {
        private String email;
        private String securityQuestion;
        private String securityAnswer;
        private String newPassword;
        // getters and setters
    }

}
