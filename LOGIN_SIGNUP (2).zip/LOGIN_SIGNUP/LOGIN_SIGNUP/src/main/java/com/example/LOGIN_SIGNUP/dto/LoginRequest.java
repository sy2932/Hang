package com.example.LOGIN_SIGNUP.dto;

public class LoginRequest {
    public class LoginRequest {
        private String email;
        private String password;
        // getters and setters
    }

}
