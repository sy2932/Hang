package RW_Tool.Ops_User.repository;

import RW_Tool.Ops_User.model.Notification;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface NotificationRepository extends JpaRepository<Notification, String> {

    List<Notification> findByGroupName(String groupName);

    @Query("SELECT n FROM Notification n WHERE n.read = false ORDER BY n.receivedAt DESC")
    List<Notification> findUnreadNotifications();

    @Query("SELECT n FROM Notification n ORDER BY n.receivedAt DESC")
    List<Notification> findAllOrderByReceivedAtDesc();

    @Query("SELECT COUNT(n) FROM Notification n WHERE n.read = false")
    Long countUnreadNotifications();
}
