package RW_Tool.Ops_User.repository;

import RW_Tool.Ops_User.model.Employee;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    Optional<Employee> findByEmail(String email);

    List<Employee> findByDepartment(String department);

    List<Employee> findByAdminAssignedGroup(String adminAssignedGroup);

    @Query("SELECT e FROM Employee e WHERE e.adminAssignedGroup IS NOT NULL")
    List<Employee> findAllApprovedEmployees();

    @Query("SELECT e FROM Employee e WHERE LOWER(e.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Employee> findByNameContainingIgnoreCase(@Param("name") String name);

    @Query("SELECT e FROM Employee e WHERE e.adminAssignedGroup = :group AND LOWER(e.name) LIKE LOWER(CONCAT('%', :name, '%'))")
    List<Employee> findByGroupAndNameContaining(@Param("group") String group, @Param("name") String name);
}
