package com.example.LOGIN_SIGNUP.dto;

public class SignUpRequest {
        private String email;
        private String password;
        private String rePassword;
        private String securityQuestion;
        private String securityAnswer;
        private String role;
    }


