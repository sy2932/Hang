package RW_Tool.Ops_User.controller;

import RW_Tool.Ops_User.model.Employee;
import RW_Tool.Ops_User.service.OpsDashboardService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
public class EmployeeController {

    private final OpsDashboardService opsDashboardService;

    public EmployeeController(OpsDashboardService opsDashboardService) {
        this.opsDashboardService = opsDashboardService;
    }

    @GetMapping
    public ResponseEntity<List<Employee>> getAllEmployees() {
        return ResponseEntity.ok(opsDashboardService.getAllEmployees());
    }

    @GetMapping("/approved")
    public ResponseEntity<List<Employee>> getApprovedEmployees() {
        return ResponseEntity.ok(opsDashboardService.getApprovedEmployees());
    }

    @GetMapping("/department/{department}")
    public ResponseEntity<List<Employee>> getEmployeesByDepartment(@PathVariable String department) {
        return ResponseEntity.ok(opsDashboardService.searchEmployees("", department));
    }

    @GetMapping("/group/{group}")
    public ResponseEntity<List<Employee>> getEmployeesByGroup(@PathVariable String group) {
        return ResponseEntity.ok(opsDashboardService.searchEmployees("", group));
    }

    @PostMapping("/approve")
    public ResponseEntity<Employee> approveEmployee(@RequestBody Employee employee) {
        Employee approvedEmployee = opsDashboardService.saveEmployee(employee);
        opsDashboardService.updateGroupUserCounts();
        return ResponseEntity.ok(approvedEmployee);
    }
}
